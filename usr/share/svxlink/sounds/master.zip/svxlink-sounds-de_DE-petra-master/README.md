# svxlink-sounds-de_DE-petra
Achtung: diese Stimmen unterliegen Nutzungebeschränkungen. 
Sie dürfen diese Ansagen nur nutzen, wenn Sie eine Version des Linguatec Voicereaders (HOME) erwoben haben!
Weitere Informationen sind auf der Webseite von Linguatec zu finden: https://www.linguatec.de/
